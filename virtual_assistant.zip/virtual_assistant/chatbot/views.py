from django.shortcuts import render
from django.http import JsonResponse
from .models import Conversation

# Sample function to mimic chatbot response
def get_bot_response(user_input):
    # Implement actual chatbot logic here
    responses = {
        "hi": "Hello! How can I help you today?",
        "how are you": "I'm just a bot, but I'm doing great! How about you?",
                "murree":"could you want to visit Murree",
                "hotel price":"murree mall road hotel one night stay 3000 pkr",
                "bye": "Goodbye! Have a nice day!"
    }
    return responses.get(user_input.lower(), "Sorry, I didn't understand that.")

def chat_view(request):
    if request.method == 'POST':
        user_input = request.POST.get('user_input')
        bot_response = get_bot_response(user_input)

        # Save conversation to the database
        conversation = Conversation(user_input=user_input, bot_response=bot_response)
        conversation.save()

        return JsonResponse({'bot_response': bot_response})

    return render(request, 'chatbot/chat.html')
